package strategypattern;
public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-9345", "Cristiano");
        PaymentContext paymentContext = new PaymentContext(creditCardPayment);
        paymentContext.executePayment(476.00);
        System.out.println();
        PaymentStrategy payPalPayment = new PayPalPayment("ronaldorolls@gmail.com");
        paymentContext = new PaymentContext(payPalPayment);
        paymentContext.executePayment(987.00);
    }
}
