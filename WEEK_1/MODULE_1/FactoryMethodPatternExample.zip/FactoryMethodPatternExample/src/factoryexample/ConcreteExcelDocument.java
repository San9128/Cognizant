package factoryexample;
public class ConcreteExcelDocument extends ExcelDocument {
    @Override
    public void open() {
        System.out.println("Opening a specific Excel document.");
    }
}
