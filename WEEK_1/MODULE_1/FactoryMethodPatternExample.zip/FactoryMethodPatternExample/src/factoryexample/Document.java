package factoryexample;

public interface Document {
	void open();
}
