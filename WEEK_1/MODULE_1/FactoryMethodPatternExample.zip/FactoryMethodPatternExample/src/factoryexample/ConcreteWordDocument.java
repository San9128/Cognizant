package factoryexample;
public class ConcreteWordDocument extends WordDocument {
    @Override
    public void open() {
        System.out.println("Opening a specific Word document.");
    }
}
