package adaptpat;
public interface PaymentProcessor {
	void processPayment(double amount);
}
