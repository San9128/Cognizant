package adaptpat;
public class PaypalGateway {
	 public void makePayment(double amount) {
	        System.out.println("Payment of $" + amount + " processed from PayPal.");
	    }
}
