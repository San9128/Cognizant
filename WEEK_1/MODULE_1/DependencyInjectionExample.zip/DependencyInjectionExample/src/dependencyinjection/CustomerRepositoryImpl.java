package dependencyinjection;
public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(String id) {
        return new Customer(id, "Ryan Gosling", "ryan.gosling@gmail.com");
    }
}
