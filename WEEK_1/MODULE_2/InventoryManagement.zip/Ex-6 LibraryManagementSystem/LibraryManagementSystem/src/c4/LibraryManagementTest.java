package c4;
import java.util.Arrays;

public class LibraryManagementTest {
    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book(2, "To Kill a Mockingbird", "Harper Lee"),
            new Book(3, "1984", "George Orwell"),
            new Book(4, "Pride and Prejudice", "Jane Austen"),
            new Book(5, "The Catcher in the Rye", "J.D. Salinger")
        };

        Arrays.sort(books, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));

        System.out.println("Testing Linear Search:");
        Book book1 = LibraryManagementSystem.linearSearchByTitle(books, "1984");
        System.out.println(book1 != null ? book1 : "Book not found.");

        System.out.println("\nTesting Binary Search:");
        Book book2 = LibraryManagementSystem.binarySearchByTitle(books, "1984");
        System.out.println(book2 != null ? book2 : "Book not found.");
    }
}
