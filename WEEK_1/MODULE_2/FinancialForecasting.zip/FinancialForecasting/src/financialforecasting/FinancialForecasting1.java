package financialforecasting;
public class FinancialForecasting1 extends FinancialForecasting{
    public static double calculateFutureValueIterative(double currentValue, double growthRate, int periods) {
        double futureValue = currentValue;
        for (int i = 0; i < periods; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        double initialValue = 1000; 
        double growthRate = 0.05;
        int periods = 10;

        double futureValueRecursive = calculateFutureValue(initialValue, growthRate, periods);
        double futureValueIterative = calculateFutureValueIterative(initialValue, growthRate, periods);

        System.out.printf("The future value (recursive) after %d periods is: $%.2f%n", periods, futureValueRecursive);
        System.out.printf("The future value (iterative) after %d periods is: $%.2f%n", periods, futureValueIterative);
    }
}
