package com.library;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.library.service.BookService;

public class App {
    public static void main(String[] args) {
        // Load the Spring context using annotation-based configuration
        ApplicationContext context = new AnnotationConfigApplicationContext("com.library");

        // Retrieve the BookService bean from the context
        BookService bookService = context.getBean(BookService.class);

        // Call a method on the BookService to verify configuration
        bookService.performService();
    }
}
