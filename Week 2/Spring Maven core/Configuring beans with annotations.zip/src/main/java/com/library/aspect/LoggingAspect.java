package com.library.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class LoggingAspect {

    @Pointcut("execution(* com.library.service.*.*(..))")
    private void serviceMethods() {}

    @Before("serviceMethods()")
    public void logMethodStart() {
        System.out.println("Method execution has  started...");
    }

    @AfterReturning("serviceMethods()")
    public void logMethodEnd() {
        System.out.println("Method execution completedsuccessfully .");
    }

    @Before("serviceMethods()")
    public void logMethodExecutionTime() {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        // No implementation needed for timing, just example
    }
}
